<div align="center">
<img src="https://i.imgur.com/MkFud1l.png" align="center" alt="Logo" height="100">
<br>
<br>
<strong><i>An open-source discord bot for SA-MP(San Andreas Multiplayer) Servers/ Communities</i></strong>
<br>
<br>
<hr>



<a href="https://travis-ci.com/abhaysv/SAMP-Discord-Bot-Dumbledore">
    <img src="https://img.shields.io/travis/com/abhaysv/SAMP-Discord-Bot-Dumbledore.svg?style=for-the-badge" alt="Build">
</a>

<a href="https://github.com/abhaysv/SAMP-Discord-Bot-Dumbledore">
    <img src="https://img.shields.io/github/languages/top/abhaysv/SAMP-Discord-Bot-Dumbledore.svg?colorB=f0db4f&style=for-the-badge" alt="Languages">
</a>

<br>

<a href="https://github.com/abhaysv/SAMP-Discord-Bot-Dumbledore">
    <img src="https://img.shields.io/github/package-json/v/abhaysv/SAMP-Discord-Bot-Dumbledore.svg?colorB=Orange&style=for-the-badge" alt="Version">
</a>

<a href="https://github.com/abhaysv/SAMP-Discord-Bot-Dumbledore/issues">
    <img src="https://img.shields.io/github/issues/abhaysv/SAMP-Discord-Bot-Dumbledore.svg?style=for-the-badge&colorB=37f149" alt="Issues">
</a>

<a href="https://github.com/abhaysv/SAMP-Discord-Bot-Dumbledore/pulls">
    <img src="https://img.shields.io/github/issues-pr/abhaysv/SAMP-Discord-Bot-Dumbledore.svg?style=for-the-badge&colorB=37f149" alt="Pull Request">
</a>

<br>
<br>
</div>
<hr>
<br>


## SAMP Discord Bot with some basic functionality. 📍
-You can query SAMP server you can query samp servers and display the no of players. (/players)<br />
-A CMD to reply with the server IP<br />
-It has a feature similar to the application-bot where it can initiate Applications in DM. (/apply) [ This feature will be refined in future versions]<br />
-It can search for bans (/sban) , it has an example implementation you will need to edit the SQL accordingly.<br />
-It can revoke the bans (/unbanban) , it has an example implementation you will need to edit the SQL accordingly.<br />
-Logging feature for things like reports, it has an example implementation you will need to edit the SQL accordingly.<br />
-A command processor which will allow you to change the bot cmd character.<br />
-Utlity cmd /clear to clear messages in bulk.<br />
-Supports On the fly configuration changes.

---
## Initial Setup. 📝
-You can directly depoy this bot with a free Dyno offered by Heroku. Just signup for a free acc at heroku and click the Deploy button.<br />
-For a detailed tutorial [click here](https://github.com/abhaysv/SAMP-Discord-Bot-Dumbledore/wiki).

---

## Deployment 📝
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

---





