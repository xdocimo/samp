module.exports =  [
	"Your Ingame Name",
	"Any Previous Names",
	"How long have you been a part of WG community",
	"Have you recived any punishment or infraction recently , if so mention the reason",
	"State you intentions for applying for the WG TAG",
	"Why do you think you deserve the [WG] Tag"
];
